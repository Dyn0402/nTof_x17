"""
Calibration bundle: everything the forward model needs for one detector under
one set of run conditions.

A bundle is a directory:

    <name>/
        bundle.json     hypers, v, geometry, provenance
        arrays.npz      per-plane impulse templates, per-channel gain maps

**A bundle used outside the conditions it was fitted for is a silent error** —
the sharing kernel, the template and v are all detector- and condition-specific
(det4's kY is 2.36 against det3's 1.375; v moves from 12 to 39 um/ns across the
drift-HV scan). Hence `conditions` is a required, recorded field and
`check_conditions()` is called by the reconstruction driver.
"""
from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass, field, asdict
from typing import Dict, Optional

import numpy as np

# hyper names in the order the calibration optimiser uses them
HYPER_NAMES = ('c1', 'c2', 'kY', 'tau_s', 'sigma_s', 'sigma_p0', 'Dp')


def _git_commit(path: str) -> str:
    try:
        return subprocess.run(['git', 'rev-parse', '--short', 'HEAD'],
                              cwd=path, capture_output=True, text=True,
                              timeout=10).stdout.strip() or 'unknown'
    except Exception:
        return 'unknown'


# ---------------------------------------------------------------- the c2 gate
# The +-2 strip is reached only THROUGH the +-1 strip, so c2 < c1 always. The
# ref-pinned cosmic chi2 is genuinely flat in this direction (sloppy-mode
# analysis 2026-08-17), so an unconstrained fit walks there and lands at c2 > c1
# -- det3 1.14, det2 1.53, det7 1.75, det4 2.12. The H4 head-on beam measures
# the ratio directly and model-free at 0.45 +- 0.02 over a 2.6x range of drift
# field (sps_beam_test_26/analysis/sharing_kernel); near-vertical bench cosmics
# give 0.63 +- 0.10 on det3. An inverted bundle is therefore not a fit result,
# it is a defect, and every product built on one was retired on 2026-08-21.
#
# This gate is what stops one coming back. It refuses at LOAD and at INSTALL,
# which between them cover every path into the forward model.
C2_GATE_ENV = 'WFT_ALLOW_INVERTED_KERNEL'


def effective_c2(hyper: dict, plane: str | None = None) -> float:
    """The +-2 amplitude the model will actually use, on the BASE c1 (before
    the per-plane kY/cX scaling, which multiplies c1 and c2 alike and so
    cannot change the ordering). MUST mirror build_matrix: when the bundle
    carries ``c2_over_c1`` (or, for ``plane``, ``c2_over_c1_<plane>``) the
    stored ``c2`` (0.0) is ignored and the ratio is applied to c1."""
    r = hyper.get(f'c2_over_c1_{plane}') if plane else None
    if r is None:
        r = hyper.get('c2_over_c1')
    return float(r) * float(hyper['c1']) if r is not None else float(hyper['c2'])


def check_kernel_ordering(hyper: dict, where: str = '') -> None:
    """Raise unless c2 < c1. Set WFT_ALLOW_INVERTED_KERNEL=1 to read a parked
    bundle deliberately -- the only legitimate use is a report *about* the
    defect, and it must say so."""
    c1 = float(hyper.get('c1', 0.0))
    # judged per view: a per-view ratio can be inverted on one plane only
    c2 = max(effective_c2(hyper, p) for p in ('x', 'y'))
    if c1 <= 0 or c2 <= c1:
        return
    if os.environ.get(C2_GATE_ENV):
        print(f'[wft] WARNING: inverted sharing kernel c2/c1 = {c2 / c1:.2f} '
              f'allowed by {C2_GATE_ENV} {where}', flush=True)
        return
    raise ValueError(
        f'inverted sharing kernel: c2 = {c2:.4f} > c1 = {c1:.4f} '
        f'(ratio {c2 / c1:.2f}){" in " + where if where else ""}. The +-2 strip '
        f'is reached only through the +-1 strip, so this cannot be physical; '
        f'it is the defect retired on 2026-08-21. Use the detector\'s '
        f'calib_bundle_r06 (c2 = 0.6 x c1). To read a parked bundle anyway, '
        f'set {C2_GATE_ENV}=1.')


#: 'lqc' is 'lq' over the depth bins the DAQ window constrains only; 'lq' uses
#: the full q_sum, which NNLS inflates to 1e6-1e26 on 12-33 % of run_145 tracks
#: (bins arriving after the last sample; wft.model.constrained_bins)
XY_FEATURES = ('lq', 'lqc', 'u50', 'u90', 't0')


def check_xy_pairing(p: dict, where: str = '') -> None:
    """Raise unless ``p`` is empty or a usable x/y pairing calibration:
    ``features`` from XY_FEATURES, each with a ``median`` and a positive ``rsig``."""
    if not p:
        return
    feats = list(p.get('features') or [])
    med, sig = p.get('median') or {}, p.get('rsig') or {}
    bad = [k for k in feats if k not in XY_FEATURES or k not in med
           or not float(sig.get(k, 0.0)) > 0]
    if not feats or bad:
        raise ValueError(f'unusable xy_pairing calibration{" in " + where if where else ""}: '
                         f'features {feats}, bad {bad}')


@dataclass
class CalibrationBundle:
    """Per-detector, per-condition calibration for the forward model."""

    # --- model calibration ---
    hyper: Dict[str, float]                 # c1, c2, kY, tau_s, sigma_s, sigma_p0, Dp
    v_drift: float                          # um/ns
    grid: np.ndarray                        # template time grid [ns]
    tmpl: Dict[str, np.ndarray]             # per-plane impulse response
    gain: Dict[str, np.ndarray]             # per-channel gain (512), 1.0 = unmeasured
    dt_xy: Dict[int, float] = field(default_factory=dict)   # t0x - t0y by ftst diff

    # --- absolute-t0 prior (T1.1, 2026-08-11): the scintillator trigger fixes
    # each plane's t0 up to the ftst clock phase. t0_abs[plane][ftst] is the
    # predicted t0 [ns]; t0_prior_sigma is the penalty width [ns] (0 = prior
    # disabled). Per run condition like everything else in the bundle.
    t0_abs: Dict[str, Dict[int, float]] = field(default_factory=dict)
    t0_prior_sigma: float = 0.0

    # --- dead-channel mask (T1.3, 2026-08-12): channels with no signal RATE
    # (a broken connection downstream of the preamp still has a normal
    # pedestal, so this is a rate mask, not a pedestal mask). Dead strips are
    # censored samples: dropped from the chi2 sum entirely, no penalty in
    # either direction. Per run condition like everything else here.
    dead: Dict[str, list] = field(default_factory=dict)

    # --- hot-channel wildcard (HANDOFF_D_NOISY_CHANNELS.md, 2026-09-08):
    # channels firing far above their local occupancy neighbourhood --
    # unlike ``dead``, these DO carry signal (coherent/correlated noise fit as
    # a wide, dilute cluster), so they are not censored. Dylan's spec: never
    # seed on one (wft.seed.seed_candidates/seeds_from_hits), keep it in the
    # fit down-weighted (wft.model.prep_plane inflates its noise), cap its
    # influence (HOT_NOISE_INFLATION bounds how far), never drop a track for
    # having crossed one. Measured from raw combined_hits occupancy, per
    # (detector, run condition) like everything else here --
    # sept26_prelim_analysis/noisy_channels.py.
    hot: Dict[str, list] = field(default_factory=dict)

    # --- per-plane angle-mapping constants (9dd7d6e, restored 2026-08-13).
    # The fitted width w maps to a tangent as  tan = (w*1e3 - w0[p]) / (kw[p]*v)
    # -- w0 is the zero-angle width offset and kw the scale, both measured from
    # free fits of reference tracks. These MUST round-trip: between 9dd7d6e and
    # 8-13 the fields existed in every bundle.json but not on this class, so any
    # load()->save() silently shed them and plane_fit ignored them entirely --
    # that omission is the whole fleet angle bias (arctan(w0/v) per detector,
    # up to -1.04 deg on det6). Absent in a bundle -> 0.0/1.0, which reproduces
    # the uncorrected mapping, so reco stamps whether they were found.
    w0: Dict[str, float] = field(default_factory=dict)
    kw: Dict[str, float] = field(default_factory=dict)

    # --- x/y pairing of time-degenerate tracks (2026-09-14): median and robust
    # width of each x-minus-y feature (``XY_FEATURES``) on clean single tracks
    # of this detector and condition, and which features to use. Empty = pair
    # by summed dchi2 rank only (wft.reco.select_tracks).
    xy_pairing: Dict[str, object] = field(default_factory=dict)

    # --- geometry / DAQ ---
    pitch_mm: float = 0.78
    sample_ns: float = 60.0
    n_depth_bins: int = 18                  # K: 60 ns charge bins in the fit basis
    sat_adc: float = 3550.0

    # --- sharing-kernel form: 'delay' (legacy) | 'lp' (RC-dispersed copy,
    # the H4-beam-measured structure; tau_s becomes the RC constant) ---
    share_mode: str = 'delay'

    # --- identity and provenance (recorded, and checked at reco time) ---
    detector: str = ''                      # e.g. 'mx17_3'
    run_key: str = ''                       # qa_config key the fit was done on
    conditions: Dict[str, object] = field(default_factory=dict)  # amp/drift HV, gas...
    provenance: Dict[str, object] = field(default_factory=dict)

    # ------------------------------------------------------------------ io
    def save(self, path: str, note: str = '') -> str:
        os.makedirs(path, exist_ok=True)
        np.savez_compressed(
            os.path.join(path, 'arrays.npz'),
            grid=self.grid, tmpl_x=self.tmpl['x'], tmpl_y=self.tmpl['y'],
            gain_x=self.gain['x'], gain_y=self.gain['y'])
        prov = dict(self.provenance)
        prov.setdefault('code_commit', _git_commit(os.path.dirname(
            os.path.abspath(__file__))))
        if note:
            prov['note'] = note
        self.provenance = prov
        check_kernel_ordering(self.hyper, where=path)
        check_xy_pairing(self.xy_pairing, where=path)
        meta = dict(hyper={k: float(v) for k, v in self.hyper.items()},
                    v_drift=float(self.v_drift),
                    dt_xy={str(k): float(v) for k, v in self.dt_xy.items()},
                    t0_abs={p: {str(k): float(v) for k, v in d.items()}
                            for p, d in self.t0_abs.items()},
                    t0_prior_sigma=float(self.t0_prior_sigma),
                    dead={p: [int(c) for c in ch]
                          for p, ch in self.dead.items()},
                    hot={p: [int(c) for c in ch]
                        for p, ch in self.hot.items()},
                    w0={p: float(v) for p, v in self.w0.items()},
                    kw={p: float(v) for p, v in self.kw.items()},
                    xy_pairing=self.xy_pairing,
                    pitch_mm=self.pitch_mm, sample_ns=self.sample_ns,
                    n_depth_bins=self.n_depth_bins, sat_adc=self.sat_adc,
                    share_mode=self.share_mode,
                    detector=self.detector, run_key=self.run_key,
                    conditions=self.conditions, provenance=prov)
        with open(os.path.join(path, 'bundle.json'), 'w') as f:
            json.dump(meta, f, indent=1)
        return path

    @classmethod
    def load(cls, path: str) -> 'CalibrationBundle':
        with open(os.path.join(path, 'bundle.json')) as f:
            m = json.load(f)
        z = np.load(os.path.join(path, 'arrays.npz'))
        check_kernel_ordering(m['hyper'], where=path)
        check_xy_pairing(m.get('xy_pairing') or {}, where=path)
        return cls(hyper=m['hyper'], v_drift=m['v_drift'],
                   grid=z['grid'], tmpl={'x': z['tmpl_x'], 'y': z['tmpl_y']},
                   gain={'x': z['gain_x'], 'y': z['gain_y']},
                   dt_xy={int(k): v for k, v in m.get('dt_xy', {}).items()},
                   t0_abs={p: {int(k): float(v) for k, v in d.items()}
                           for p, d in m.get('t0_abs', {}).items()},
                   t0_prior_sigma=m.get('t0_prior_sigma', 0.0),
                   dead={p: [int(c) for c in ch]
                         for p, ch in m.get('dead', {}).items()},
                   hot={p: [int(c) for c in ch]
                       for p, ch in m.get('hot', {}).items()},
                   w0={p: float(v) for p, v in (m.get('w0') or {}).items()},
                   kw={p: float(v) for p, v in (m.get('kw') or {}).items()},
                   xy_pairing=m.get('xy_pairing') or {},
                   pitch_mm=m.get('pitch_mm', 0.78),
                   sample_ns=m.get('sample_ns', 60.0),
                   n_depth_bins=m.get('n_depth_bins', 18),
                   sat_adc=m.get('sat_adc', 3550.0),
                   share_mode=m.get('share_mode', 'delay'),
                   detector=m.get('detector', ''), run_key=m.get('run_key', ''),
                   conditions=m.get('conditions', {}),
                   provenance=m.get('provenance', {}))

    # ------------------------------------------------- legacy R&D artifacts
    @classmethod
    def from_legacy(cls, wf_dir: str, detector: str = '', run_key: str = '',
                    conditions: Optional[dict] = None,
                    hyper_file: str = 'hyper_v2.json') -> 'CalibrationBundle':
        """Build a bundle from the 2026-07-25/26 R&D products in a
        ``<Analysis>/.../waveform_first`` directory (templates_perplane.npz,
        gainmap.npz, dt_xy.json, hyper_v2.json). Numerics are taken verbatim —
        this is how det3/det2/det4 keep their validated calibration."""
        tz = np.load(os.path.join(wf_dir, 'templates_perplane.npz'))
        gain_path = os.path.join(wf_dir, 'gainmap.npz')
        if os.path.exists(gain_path):
            gz = np.load(gain_path)
            gain = {'x': gz['gain_x'], 'y': gz['gain_y']}
        else:
            # only det3 has a measured map; the ablation study found the 1.4 %
            # channel-gain spread changes per-event angles by less than the
            # statistical noise, so unit gains are the right default elsewhere
            gain = {'x': np.ones(512), 'y': np.ones(512)}
        with open(os.path.join(wf_dir, hyper_file)) as f:
            hj = json.load(f)
        dt = {}
        dt_path = os.path.join(wf_dir, 'dt_xy.json')
        if os.path.exists(dt_path):
            with open(dt_path) as f:
                dt = {int(k): float(v) for k, v in json.load(f).items()}
        hyper = {k: float(hj[k]) for k in HYPER_NAMES if k in hj}
        hyper.setdefault('kY', 1.0)
        return cls(hyper=hyper, v_drift=float(hj['v']),
                   grid=tz['grid'], tmpl={'x': tz['tmpl_x'], 'y': tz['tmpl_y']},
                   gain=gain, dt_xy=dt,
                   detector=detector, run_key=run_key,
                   conditions=conditions or {},
                   provenance=dict(source=wf_dir, hyper_file=hyper_file,
                                   n_train=hj.get('n_train'),
                                   chi2=hj.get('chi2'),
                                   imported='legacy waveform_first R&D'))

    # ------------------------------------------------------------- checks
    def check_conditions(self, conditions: dict, strict: bool = False) -> list:
        """Compare run conditions against the ones the bundle was fitted for.
        Returns a list of human-readable mismatches (empty = fine)."""
        bad = []
        for k, want in self.conditions.items():
            got = conditions.get(k)
            if got is None:
                continue
            if isinstance(want, (int, float)) and isinstance(got, (int, float)):
                if abs(float(want) - float(got)) > 1e-6:
                    bad.append(f'{k}: bundle {want} vs run {got}')
            elif want != got:
                bad.append(f'{k}: bundle {want!r} vs run {got!r}')
        if bad and strict:
            raise ValueError('calibration bundle does not match run conditions: '
                             + '; '.join(bad))
        return bad

    def summary(self) -> str:
        h = self.hyper
        # c2 may be SLAVED: when the bundle carries c2_over_c1, build_matrix
        # ignores the stored c2 (which is 0.0) and uses ratio * c1. Printing
        # the stored field there says "no +-2 copy" about a model that draws
        # one -- report what the model actually uses, and say it is slaved.
        r = h.get('c2_over_c1')
        c2 = float(r) * h['c1'] if r is not None else h['c2']
        c2s = f"c2={c2:.3f}" + (f" (={r:g}xc1)" if r is not None else '')
        rp = {p: h.get(f'c2_over_c1_{p}') for p in ('x', 'y')}
        if any(v is not None for v in rp.values()):
            c2s = 'c2/c1 per view ' + ', '.join(
                f'{p}={effective_c2(h, p) / h["c1"]:.3g}' for p in ('x', 'y'))
        return (f"{self.detector or '?'} / {self.run_key or '?'} "
                f"[{self.share_mode}]: "
                f"v={self.v_drift:.2f} um/ns, c1={h['c1']:.3f}, {c2s}, "
                f"kY={h.get('kY', 1.0):.3f}, tau_s={h['tau_s']:.0f} ns, "
                f"sigma_s={h['sigma_s']:.0f} ns, sigma_p0={h['sigma_p0']:.3f} mm, "
                f"Dp={h['Dp']:.4f}  [{self.provenance.get('code_commit', '?')}]")
